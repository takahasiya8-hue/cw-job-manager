const KEY = 'cw-job-manager-v3';
const OLD_KEYS = ['cw-job-manager-v2','lns-resource-manager-jobs-v1','job-manager-v1'];
const fields = ['title','platform','status','client','price','priority','appliedAt','applyDeadline','interviewAt','deliveryDeadline','url','proposal','memo'];
const terminalStatuses = ['納品済','終了','見送り'];
let jobs = loadJobs();
let editingId = null;
let currentStatus = 'all';

const $ = (id) => document.getElementById(id);
const form = $('jobForm');
const list = $('jobList');
const tpl = $('jobTemplate');

function normalizeJob(j){
  return {
    id: j.id || crypto.randomUUID(),
    title: j.title || '',
    platform: j.platform || 'クラウドワークス',
    status: normalizeStatus(j.status || '応募前'),
    client: j.client || '',
    price: j.price || '',
    priority: j.priority || '★★★',
    appliedAt: j.appliedAt || '',
    applyDeadline: j.applyDeadline || j.deadline || '',
    interviewAt: j.interviewAt || j.due || '',
    deliveryDeadline: j.deliveryDeadline || '',
    url: j.url || '',
    proposal: j.proposal || '',
    memo: j.memo || '',
    createdAt: j.createdAt || new Date().toISOString(),
    updatedAt: j.updatedAt || new Date().toISOString()
  };
}
function normalizeStatus(s){
  const map = {'検討中':'応募前','応募済み':'応募済','受注':'受注','納品済み':'納品済'};
  return map[s] || s;
}
function loadJobs(){
  try{
    const current = JSON.parse(localStorage.getItem(KEY) || 'null');
    if(Array.isArray(current)) return current.map(normalizeJob);
    for(const key of OLD_KEYS){
      const old = JSON.parse(localStorage.getItem(key) || 'null');
      if(Array.isArray(old) && old.length){
        const migrated = old.map(normalizeJob);
        localStorage.setItem(KEY, JSON.stringify(migrated));
        return migrated;
      }
    }
  }catch(e){ console.warn(e); }
  return [];
}
function save(){
  localStorage.setItem(KEY, JSON.stringify(jobs));
  render();
}
function escapeText(v=''){ return String(v).trim(); }
function parseDate(value){ if(!value) return null; const d = new Date(value); return Number.isNaN(d.getTime()) ? null : d; }
function startOfToday(){ const d = new Date(); d.setHours(0,0,0,0); return d; }
function dayDiff(value){ const d=parseDate(value); if(!d) return null; const a=startOfToday(); const b=new Date(d); b.setHours(0,0,0,0); return Math.round((b-a)/86400000); }
function formatDate(value, withTime=false){
  const d = parseDate(value); if(!d) return '未入力';
  const opt = withTime ? {month:'numeric',day:'numeric',weekday:'short',hour:'2-digit',minute:'2-digit'} : {month:'numeric',day:'numeric',weekday:'short'};
  return new Intl.DateTimeFormat('ja-JP', opt).format(d);
}
function formatPrice(v){
  const raw = String(v || '').replace(/[円,\s]/g,'');
  if(!raw) return '未入力';
  const n = Number(raw);
  return Number.isFinite(n) ? `¥${n.toLocaleString()}` : String(v);
}
function taskLabel(type, value){
  const diff = dayDiff(value);
  if(diff === null) return null;
  if(diff < 0) return `期限超過：${type}`;
  if(diff === 0) return `今日：${type}`;
  if(diff === 1) return `明日：${type}`;
  if(diff <= 7) return `あと${diff}日：${type}`;
  return null;
}
function taskItems(job){
  const items=[];
  const a=taskLabel('応募締切', job.applyDeadline); if(a) items.push({text:a,date:job.applyDeadline,level:dayDiff(job.applyDeadline)<=0?'red':'orange'});
  const i=taskLabel('面談', job.interviewAt); if(i) items.push({text:i,date:job.interviewAt,level:dayDiff(job.interviewAt)<=0?'red':'orange'});
  const d=taskLabel('納期', job.deliveryDeadline); if(d) items.push({text:d,date:job.deliveryDeadline,level:dayDiff(job.deliveryDeadline)<=0?'red':'orange'});
  return items;
}
function renderToday(){
  const rows=[];
  jobs.filter(j=>!terminalStatuses.includes(j.status)).forEach(j=>taskItems(j).forEach(t=>rows.push({job:j,...t})));
  rows.sort((a,b)=>String(a.date).localeCompare(String(b.date)));
  $('todayBadge').textContent = `${rows.length}件`;
  $('todayList').innerHTML = rows.length ? rows.map(r=>`<div class="today-item ${r.level}"><strong>${r.text}</strong><br>${safe(r.job.title)}（${safe(r.job.platform)}）<br><span>${formatDate(r.date, r.date.includes('T'))}</span></div>`).join('') : '<p class="empty">直近7日以内の締切・面談・納期はありません。</p>';
}
function safe(v=''){ const div=document.createElement('div'); div.textContent=String(v); return div.innerHTML; }
function render(){
  const q = $('search').value.trim().toLowerCase();
  const shown = jobs.filter(j => (currentStatus==='all' || j.status===currentStatus) && [j.title,j.platform,j.status,j.client,j.memo,j.proposal].join(' ').toLowerCase().includes(q));
  $('totalCount').textContent = jobs.length;
  $('activeCount').textContent = jobs.filter(j=>!terminalStatuses.includes(j.status)).length;
  $('deadlineSoonCount').textContent = jobs.filter(j=>taskItems(j).length).length;
  renderToday();
  list.innerHTML = '';
  if(!shown.length){ list.innerHTML = '<p class="empty">表示できる案件がありません。</p>'; return; }
  shown.sort((a,b)=>sortKey(a).localeCompare(sortKey(b))).forEach(j=>{
    const node = tpl.content.cloneNode(true);
    node.querySelector('h3').textContent = j.title || '無題の案件';
    node.querySelector('.subline').textContent = `${j.platform} ／ ${j.client || '相手未入力'} ／ ${j.priority}`;
    node.querySelector('.status-pill').textContent = j.status;
    node.querySelector('.job-meta').innerHTML = [
      `金額：${formatPrice(j.price)}`,
      `応募日：${formatDate(j.appliedAt)}`,
      `応募締切：${formatDate(j.applyDeadline)}`,
      `面談日時：${formatDate(j.interviewAt, true)}`,
      `納期：${formatDate(j.deliveryDeadline)}`,
      j.url ? `URL：<a class="link" href="${safe(j.url)}" target="_blank" rel="noopener">募集ページを開く</a>` : 'URL：未入力'
    ].join('<br>');
    node.querySelector('.memo').textContent = j.memo || 'メモなし';
    node.querySelector('.edit').onclick = () => editJob(j.id);
    node.querySelector('.copy').onclick = () => copyJob(j);
    node.querySelector('.delete').onclick = () => deleteJob(j.id);
    list.appendChild(node);
  });
}
function sortKey(j){ return j.interviewAt || j.applyDeadline || j.deliveryDeadline || '9999-12-31'; }
function editJob(id){
  const j = jobs.find(x=>x.id===id); if(!j) return;
  editingId = id; $('formTitle').textContent = '案件を編集'; $('cancelEditBtn').hidden = false;
  fields.forEach(k => { if($(k)) $(k).value = j[k] || ''; });
  window.scrollTo({top:0, behavior:'smooth'});
}
function resetForm(){ editingId=null; form.reset(); $('formTitle').textContent='案件を追加'; $('cancelEditBtn').hidden=true; }
function deleteJob(id){ if(confirm('この案件を削除しますか？')){ jobs = jobs.filter(j=>j.id!==id); save(); } }
async function copyJob(j){
  const text = `【案件名】${j.title || '未入力'}\n【媒体】${j.platform}\n【状況】${j.status}\n【相手】${j.client || '未入力'}\n【金額】${formatPrice(j.price)}\n【応募日】${formatDate(j.appliedAt)}\n【応募締切】${formatDate(j.applyDeadline)}\n【面談日時】${formatDate(j.interviewAt,true)}\n【納期】${formatDate(j.deliveryDeadline)}\n【URL】${j.url || '未入力'}\n【メモ】${j.memo || 'なし'}\n\n【応募文】\n${j.proposal || 'なし'}`;
  try{ await navigator.clipboard.writeText(text); alert('コピーしました'); }catch(e){ prompt('コピーしてください', text); }
}
form.addEventListener('submit', e=>{
  e.preventDefault();
  const data = normalizeJob(Object.fromEntries(fields.map(k => [k, escapeText($(k).value)])));
  data.id = editingId || crypto.randomUUID(); data.createdAt = editingId ? (jobs.find(j=>j.id===editingId)?.createdAt || new Date().toISOString()) : new Date().toISOString(); data.updatedAt = new Date().toISOString();
  jobs = editingId ? jobs.map(j=>j.id===editingId ? data : j) : [data, ...jobs];
  resetForm(); save();
});
$('clearBtn').onclick = resetForm; $('cancelEditBtn').onclick = resetForm; $('search').oninput = render;
$('statusFilter').addEventListener('click', e=>{ const b=e.target.closest('.chip'); if(!b) return; currentStatus=b.dataset.status; document.querySelectorAll('.chip').forEach(x=>x.classList.toggle('active', x===b)); render(); });
$('backupBtn').onclick = () => {
  const blob = new Blob([JSON.stringify({version:3, exportedAt:new Date().toISOString(), jobs}, null, 2)], {type:'application/json'});
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `案件管理バックアップ_${new Date().toISOString().slice(0,10)}.json`; a.click(); URL.revokeObjectURL(a.href);
};
$('restoreBtn').onclick = () => $('restoreFile').click();
$('restoreFile').addEventListener('change', async e=>{
  const file = e.target.files[0]; if(!file) return;
  try{ const data = JSON.parse(await file.text()); const restored = Array.isArray(data) ? data : data.jobs; if(!Array.isArray(restored)) throw new Error('invalid'); if(confirm('現在のデータを復元データで置き換えますか？')){ jobs = restored.map(normalizeJob); save(); alert('復元しました'); }}catch(err){ alert('復元に失敗しました。JSONバックアップファイルを選んでください。'); }
  e.target.value = '';
});
$('notifyBtn').onclick = async () => {
  if(!('Notification' in window)){ alert('このブラウザは通知に対応していません。'); return; }
  const result = await Notification.requestPermission();
  alert(result === 'granted' ? '通知を許可しました。アプリを開いている間、今日の予定を確認できます。' : '通知は許可されませんでした。');
};
function notifyTodayOnce(){
  if(!('Notification' in window) || Notification.permission !== 'granted') return;
  const today = new Date().toISOString().slice(0,10);
  const sentKey = `${KEY}-notified-${today}`;
  if(localStorage.getItem(sentKey)) return;
  const count = jobs.flatMap(taskItems).filter(t=>dayDiff(t.date)===0).length;
  if(count){ new Notification('案件管理', {body:`今日対応する案件予定が${count}件あります。`}); localStorage.setItem(sentKey,'1'); }
}
if('serviceWorker' in navigator){ window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{})); }
render(); notifyTodayOnce(); setInterval(notifyTodayOnce, 60*60*1000);
